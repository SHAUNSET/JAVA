import java.lang.reflect.Array;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        //2D ArrayLists = a dynamic list of lists
        // You can change the size of these lists during runtime.

        ArrayList<ArrayList<String>> groceryList = new ArrayList<>();


        ArrayList<String> bakerylist = new ArrayList();
        bakerylist.add("pasta");
        bakerylist.add("garlic bread");
        bakerylist.add("donuts");


        ArrayList<String> producelist = new ArrayList();
        producelist.add("tomatoes");
        producelist.add("zucchini");
        producelist.add("peppers");


        ArrayList<String> drinksList = new ArrayList();
        drinksList.add("soda");
        drinksList.add("coffee");


        groceryList.add(bakerylist);
        groceryList.add(producelist);
        groceryList.add(drinksList);

        //System.out.println(groceryList);
        //System.out.println(groceryList.get(0));
        System.out.println(groceryList.get(2).get(1));



    }
}