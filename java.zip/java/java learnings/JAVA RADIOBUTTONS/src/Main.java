public class Main{

    public static void main(String[] args) {

        // JRadioButton = One or more buttons in a grouping in which only 1 may be selected per group

        new MyFrame();

    }
}