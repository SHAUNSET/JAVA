import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {

        //JOptionPane.showMessageDialog(null, "This is some useless info.","title", JOptionPane.PLAIN_MESSAGE);
        //JOptionPane.showMessageDialog(null, "Here is some useless info", "title", JOptionPane.INFORMATION_MESSAGE);
        //JOptionPane.showMessageDialog(null, "really?", "title", JOptionPane.QUESTION_MESSAGE);
        //while (true) {
            //JOptionPane.showMessageDialog(null, "Your computer has a VIRUS!", "title", JOptionPane.WARNING_MESSAGE);
        //}
        //JOptionPane.showMessageDialog(null, "CALL TECH SUPPORT OR ELSE!", "title", JOptionPane.ERROR_MESSAGE);

       // int answer = JOptionPane.showConfirmDialog(null, "bro, do you even code?" );
       // System.out.println(JOptionPane.showConfirmDialog(null, "bro, do you even code?","this is my titile", JOptionPane.YES_NO_CANCEL_OPTION ));
       // String name = JOptionPane.showInputDialog("What is your name?: ");
        //System.out.println("Hello "+ name );

        ImageIcon icon = new ImageIcon("smile.png");
        String[] responses = {"No, you are!","thank you!","*blush*"};
        int answer = JOptionPane.showOptionDialog(
                null,
                "You are the best! :D",
                "Secret message",
                JOptionPane.DEFAULT_OPTION,
                0,
                icon,
                responses,
                responses[0]);
        System.out.println(answer);

       /* JFrame frame= new JFrame();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setVisible(true);

        ImageIcon icon = new ImageIcon("smile.png");
        frame.setIconImage(icon.getImage()); */

    }
}
