public class Car {

    String name;

    Car(String name) {
        this.name = name;

    }
}
