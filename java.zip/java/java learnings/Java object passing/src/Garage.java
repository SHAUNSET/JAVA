public class Garage {

    void park(Car car) {
        System.out.println("The "+car.name+" is parked in the garage");
    }

}
