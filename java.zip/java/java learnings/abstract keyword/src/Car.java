public class Car extends Vehicle{

    @Override
    void go() {
        System.out.println("The driver is driving the car");

    }
}
