public class Main {
    public static void main(String[] args) {


        // abstract =  	abstract classes cannot be instantiated, but they can have a subclass
        //				abstract methods are declared without an implementation

        //Vehicle vehicle = new Vehicle(); (this will not work as it needs certain type of vehicle
        // and not any vague vehicle)


        Car car = new Car();

        car.go();

    }
}