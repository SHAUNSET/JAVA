public abstract class Vehicle {

    abstract void go();

}
