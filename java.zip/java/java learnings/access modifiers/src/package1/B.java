package package1;
import package2.*;

public class B {
}
