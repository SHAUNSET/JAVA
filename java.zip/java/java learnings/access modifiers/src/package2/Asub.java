package package2;

import package1.*;

public class Asub extends A {
    public static void main (String[] args){


        Asub asub = new Asub();
        System.out.println(asub.proctectedmessage);

        //C c = new C();
        //System.out.println(c.publicmessage);
    }


}
