package package2;
import package1.*;

public class C {

    String defaultmessage = "This is the default";

    public String publicmessage = "This is public";
    protected String proctectedmessage ="This is protected";
    private String privatemessage = "This is private";
}
