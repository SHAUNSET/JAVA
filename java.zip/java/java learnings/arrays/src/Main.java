public class Main {
    public static void main(String[] args) {

        // arrays= used to store multiple values in a single variable.

       /*
        String [] cars = {"Nissan", "Tesla", "BMW", "Audi"};
        cars[0] = "Mercedes";
        System.out.println(cars[0]);
        */


        //Another way of writing arrays.


        /*
        String [] cars = new String[3];
        cars[0] = "Mercedes";
        cars[1] = "Audi";
        cars[2] = "BMW";

        System.out.println(cars[0]);
         */



        String [] cars = new String[3];
        cars[0] = "Mercedes";
        cars[1] = "Audi";
        cars[2] = "BMW";

        for(int i = 0; i< cars.length; i++){
            System.out.println(cars[i]);
        }


    }
}