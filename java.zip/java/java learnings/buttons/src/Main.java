public class Main{

    public static void main(String[] args) {

        // JButton = a button that performs an action when clicked on

        new MyFrame();

    }
}