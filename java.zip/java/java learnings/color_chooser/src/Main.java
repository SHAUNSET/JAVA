public class Main{

    public static void main(String[] args) {

        // JColorChooser = A GUI mechanism that let's a user choose a color

        new MyFrame();
    }
}