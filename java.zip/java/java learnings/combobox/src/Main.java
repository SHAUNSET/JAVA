
public class Main{

    public static void main(String[] args) {

        // JComboBox = A component that combines a button or editable field and a drop-down list

        new MyFrame();

    }
}