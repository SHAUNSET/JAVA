public class Main {
    public static void main(String[] args) {

       // constructers : a special method is called when an object is instantiated (created) .

        Human human1 = new Human("Shaunak", 18, 64.6);
        Human human2 = new Human("Morty",16,50);

        System.out.println(human1.name);
        System.out.println(human2.weight);

        human1.drink();
        human2.eat();

    }
}