public class Animal {
    public void speak() {
        System.out.println("animal goes *brrrr*");
    }
}
