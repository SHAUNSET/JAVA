public class Main {
    public static void main(String[] args) {

        final double PI = 3.14159;

        //PI = 4;  //You can't change a final variable,, anything that is final can't be changed

        System.out.println(PI);

    }
}