public class Main {
    public static void main(String[] args) {

        // for loop = executes a block of code a limited amount of times

        for(int i=1; i<=10; i++) {
            System.out.println(i);
        }

        System.out.println("Happy New Year!!");

    }
}