import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {


        String name = JOptionPane.showInputDialog("Enter your name");
        JOptionPane.showMessageDialog(null, "Hello "+name);

        int age = Integer.parseInt(JOptionPane.showInputDialog("What is your age?"));
        JOptionPane.showMessageDialog(null, "Age "+age+" is eligible.");

        double height = Double.parseDouble(JOptionPane.showInputDialog("Enter your height in metres"));
        double weight = Double.parseDouble(JOptionPane.showInputDialog("Enter your weight in kgs"));

        double bmi = height * height;
        double BMI = weight / bmi ;
        JOptionPane.showMessageDialog(null, "Your BMI is "+BMI);

    }
}