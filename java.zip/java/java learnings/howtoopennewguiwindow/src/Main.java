public class Main {

    public static void main(String[] args) {

        LaunchPage launchPage = new LaunchPage();

    }
}