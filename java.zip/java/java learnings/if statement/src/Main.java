import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

       Scanner scanner = new Scanner(System.in);

        System.out.println("Wwhat is your age? ");
        int age = scanner.nextInt();

        // if statement performs a block of code if it's condition evaluated to be true.

        if (age>=60){
            System.out.println("You're a Boomer!");
        }
        else if (age<18){
            System.out.println("You're a Kid.");
        }
        else if (age>=18){
            System.out.println("You're an adult.");
        }
    }
}