public class Bicycle extends Vehicle {      //SUB CLASS

    int wheels = 2;
    int pedals = 2;

}
