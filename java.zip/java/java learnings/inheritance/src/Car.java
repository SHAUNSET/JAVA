public class Car extends Vehicle {      //SUB CLASS

    int wheels = 4;
    int doors = 4;

}
