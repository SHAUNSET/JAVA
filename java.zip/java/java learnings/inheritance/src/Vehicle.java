public class Vehicle {                //PARENT CLASS/ SUPER CLASS

    double speed;

    void go(){
        System.out.println("This vehicle is moving");
    }
    void stop(){
        System.out.println("This vehicle is stopped");
    }
}

