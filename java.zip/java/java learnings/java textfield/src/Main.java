public class Main {
    public static void main(String[] args) {

        // JTextField = A GUI textbox component that can be used to add, set, or get text

        new MyFrame();
    }
}