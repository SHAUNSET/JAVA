public class Main {
    public static void main(String[] args) {

       Human human = new Human("Rick", 78, 80);
       Human human1 = new Human("gunny", 55 , 40);

       System.out.println(human.name);




    }
}