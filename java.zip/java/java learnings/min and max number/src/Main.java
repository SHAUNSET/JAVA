import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a number");
        double x = scanner.nextDouble();

        System.out.println("Enter another number");
        double y = scanner.nextDouble();

        double z = Math.max(x , y);
        double a = Math.min(x , y);

        System.out.println("The greater number is "+z);
        System.out.println("The smaller number is "+a);



    }
}