public class Main {
    public static void main(String[] args) {

        System.out.println("I love pizza.");
        System.out.println("It's really good.");
        System.out.print("I also love burgers\n");
        System.out.println("\tps:burger combo with fries and drinks is best\n");
        System.out.println("These are some foods I like");

        //This is a comment

        /*
        This
        is
        also
        comment
         */
        

    }
}