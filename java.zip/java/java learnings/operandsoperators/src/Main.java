public class Main {
    public static void main(String[] args) {

        // expression = operands and operators
        //operands = values, variables, numbers, quantities.
        //operators = + - / *

        int friends = 10;
        friends = friends + 1;
        friends = friends - 6;
        friends = friends * 10;
        friends = friends / 2;
        friends = friends / 4;
        friends = friends % 5;
        friends++;
        friends--;

        System.out.println("number of friends = "+friends);


    }
}