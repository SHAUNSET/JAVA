public class Vehicle {

    public void go() {
        // TODO Auto-generated method stub

    }
}