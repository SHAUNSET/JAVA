public class Main {


    public static void main(String[] args)
    {

        // JSlider =  GUI component that lets user enter a value
        //    by using an adjustable sliding knob on a track

        SliderDemo sliderDemo = new SliderDemo();

    }

}