public class Main {
    public static void main(String[] args) {

        // String = a reference data type that can store one or more characters
        // reference data types have acces to useful methods

        String name = "Shaunak";

        boolean result = name.equalsIgnoreCase("SHAUNAK");
       /*int result = name.length();
        char result = name.charAt(2);
        int result = name.indexOf("u");
        boolean result = name.isEmpty();
        String result = name.toUpperCase();
        String result = name.trim();
        String result = name.replace('a', 'o');
        */
        System.out.println(result);
    }
}