import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //switch = statement that allows a variable to be tested for equality against a list of values.

        Scanner scanner = new Scanner(System.in);

        System.out.println("What is your today's day?");
        String day = scanner.nextLine();

        switch(day) {
            case "Sunday" : System.out.println("Sól is a goddess in Norse mythology. 'Sol' means Sun. Over time, the day of the sun became Sunday.\n" +
                    "In the runic alphabet, the rune-S name is Sun.");
            break;
            case "Monday" : System.out.println("The name Monday is related to the moon. The Latin name for moon is 'Luna', and in French Monday is still called 'Lundí'.");
            break;
            case "Tuesday" : System.out.println("Mars is a god of war, and so is the Nordic god 'Tyr' or 'Tír'.It is Týr who has given his name to Tuesday.");
            break;
            case "Wednesday" : System.out.println("Odin can be compared to the Roman god Mercury, so in the Nordic tradition Odin (also known as 'Woden') gave his name to Wednesday.");
            break;
            case "Thursday" : System.out.println("Thor is reminiscent of Jupiter, as they both deal with lightning and thunder. So this day of the week became Thursday.");
            break;
            case "Friday" : System.out.println("Venus is the goddess of love, and so is Frigg (and maybe also Freya, as they may have originally been the same goddess).\n" +
                    "Frígg gave the name to Friday. ");
            break;
            case "Saturday" : System.out.println("Most inexplicable among the Old Norse day-names is laugardagr.\n" +
                    "\n" +
                    "'Laug' mean bath or hot water and 'dagr' means day. So you can translate the Nordic word for Saturday into 'the day of the hot water' or 'bathing dag'");
            break;
            default : System.out.println("That is not a day.");
        }


    }
}