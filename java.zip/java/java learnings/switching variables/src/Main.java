public class Main {
    public static void main(String[] args) {

        String x = "water";
        String y = "oil";
        String temp= null;

        /*
        If the code was to be like this:
        temp=x;
        x=y;
        y=temp;
        The variables will swap.
         */

        System.out.println("First fluid is "+x);
        System.out.println("Second fluid is "+y);



    }
}