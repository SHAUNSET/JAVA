public class Main {
    public static void main(String[] args) {

       int x;  //declaration
        x = 123; //assignment
        //we could combine both steps "int x = 123;"(initialization)

        System.out.println("My Earth Number is: "+x);

        long y = 12634263845382643L;
        System.out.println("My Universe number is: "+y);

        byte z = 90;
        System.out.println("My Class Number is: "+z);

        float g = 11.41f;
        System.out.println("The time at Earth is: "+g);

        double c = 128.99;
        System.out.println("The Universe time is: "+c);

        boolean d = true;
        System.out.println("The temperature on Earth:(positive) "+d);

        boolean e = false;
        System.out.println("The temperature in Universe:(positive) "+e);

        char symbol = '@';
        System.out.println("Code symbol is "+symbol);

        String name = "SHAUNAK NAIK";
        System.out.println("Data complete, Signing off - "+name);



    }
}