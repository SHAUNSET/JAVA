import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {

    // This is the text field where user input and results will be displayed
    JTextField display;

    public MyPanel() {
        setLayout(null); // Using absolute layout (manual positioning of components)

        // -------- Display TextField --------
        display = new JTextField(); // Create the display field
        display.setBounds(20, 20, 340, 50); // x=20, y=20, width=340, height=50
        display.setEditable(false); // User cannot directly type into it
        display.setHorizontalAlignment(SwingConstants.LEFT); // Align text to left
        add(display); // Add to the panel

        // -------- Buttons Panel --------
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(7, 4, 10, 10)); // Grid layout 7 rows x 4 columns with gaps
        buttonPanel.setBounds(20, 90, 340, 400); // Position under display
        add(buttonPanel); // Add to main panel

        // -------- Buttons Array --------
        // These are the labels for each button, including scientific operators
        String[] buttons = {
                "sin", "cos", "tan", "log",
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "C", "0", "=", "+",
                "(", ")", "^", "√",
        };

        // Loop through the array to create buttons dynamically
        for (String text : buttons) {
            JButton button = new JButton(text); // Create button with label
            button.addActionListener(new ButtonClickListener()); // Add click listener
            buttonPanel.add(button); // Add button to button panel
        }
    }

    // -------- Inner class: ButtonClickListener --------
    // Handles all button clicks
    private class ButtonClickListener implements java.awt.event.ActionListener {
        public void actionPerformed(java.awt.event.ActionEvent e) {
            // Get the text from the clicked button
            String buttonText = ((JButton) e.getSource()).getText();

            // -------- Clear Button Logic --------
            if (buttonText.equals("C")) {
                display.setText(""); // Clear display

                // -------- Equals Button Logic --------
            } else if (buttonText.equals("=")) {
                String expr = display.getText(); // Get the entire expression typed by the user

                try {
                    // -------- Handle Power Operation --------
                    if (expr.contains("^")) {
                        // Split expression around '^' into base and exponent
                        String[] parts = expr.split("\\^");
                        double base = Double.parseDouble(parts[0]);
                        double exp = Double.parseDouble(parts[1]);

                        // Evaluate power and display result
                        display.setText(String.valueOf(Math.pow(base, exp)));

                        // -------- Handle Square Root --------
                    } else if (expr.contains("√")) {
                        // Remove √ symbol and parse the rest
                        String num = expr.replace("√", "");
                        double value = Double.parseDouble(num);

                        // Calculate square root and display
                        display.setText(String.valueOf(Math.sqrt(value)));

                        // -------- Handle Basic Expressions --------
                    } else {
                        double result = evalBasic(expr); // Evaluate +, -, *, /
                        display.setText(String.valueOf(result));
                    }

                } catch (Exception ex) {
                    display.setText("Error"); // If invalid input
                }

                // -------- Handle All Other Buttons --------
            } else {
                // Append the button text (number or symbol) to display
                display.setText(display.getText() + buttonText);
            }
        }
    }

    // -------- Evaluate Simple Expressions --------
    // Supports two-number operations: a+b, a-b, a*b, a/b
    private double evalBasic(String expr) throws Exception {
        expr = expr.replaceAll(" ", ""); // Remove spaces

        if (expr.contains("+")) {
            String[] parts = expr.split("\\+");
            return Double.parseDouble(parts[0]) + Double.parseDouble(parts[1]);
        } else if (expr.contains("-")) {
            String[] parts = expr.split("-");
            return Double.parseDouble(parts[0]) - Double.parseDouble(parts[1]);
        } else if (expr.contains("*")) {
            String[] parts = expr.split("\\*");
            return Double.parseDouble(parts[0]) * Double.parseDouble(parts[1]);
        } else if (expr.contains("/")) {
            String[] parts = expr.split("/");
            return Double.parseDouble(parts[0]) / Double.parseDouble(parts[1]);
        } else {
            // If it's just a number without operator, return it
            return Double.parseDouble(expr);
        }
    }
}
