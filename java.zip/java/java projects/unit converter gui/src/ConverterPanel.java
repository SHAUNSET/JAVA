import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ConverterPanel extends JPanel {
    public ConverterPanel() {
        setLayout(null);

        setBackground(new Color(245, 245, 245));

        JLabel mainuserlabel = new JLabel("LENGTH CONVERSION");
        mainuserlabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        mainuserlabel.setForeground(new Color(0, 102, 204));
        mainuserlabel.setBounds(10, 10, 1000, 25);
        add(mainuserlabel);

        JLabel userLabel = new JLabel("ENTER VALUE:");
        userLabel.setBounds(10, 50, 100, 25);
        add(userLabel);

        JTextField userInput = new JTextField();
        userInput.setBounds(120, 50, 100, 25);
        userInput.setToolTipText("Enter a numeric value");
        add(userInput);

        String[] units = {"meters", "centimeters", "kilometers", "millimeters", "inches", "yards", "feet"};
        JComboBox<String> comboBox = new JComboBox<>(units);
        comboBox.setBounds(230, 50, 120, 25);
        comboBox.setToolTipText("Select unit to convert from");
        add(comboBox);

        JLabel userLabel2 = new JLabel("CONVERTED VALUE:");
        userLabel2.setBounds(10, 90, 150, 25);
        add(userLabel2);

        JTextField userOutput = new JTextField();
        userOutput.setBounds(140, 90, 100, 25);
        userOutput.setEditable(false);
        userOutput.setToolTipText("Converted result will appear here");
        add(userOutput);

        JComboBox<String> comboBox2 = new JComboBox<>(units);
        comboBox2.setBounds(250, 90, 100, 25);
        comboBox2.setToolTipText("Select unit to convert to");
        add(comboBox2);

        JButton convertButton = new JButton("Convert");
        convertButton.setBounds(10, 130, 100, 30);
        convertButton.setBackground(new Color(60, 179, 113));
        convertButton.setForeground(Color.WHITE);
        convertButton.setFocusPainted(false);
        convertButton.setToolTipText("Click to convert");
        add(convertButton);

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double inputValue = Double.parseDouble(userInput.getText());
                    String fromUnit = (String) comboBox.getSelectedItem();
                    String toUnit = (String) comboBox2.getSelectedItem();

                    double meters = convertToMeters(inputValue, fromUnit);
                    double convertedValue = convertFromMeters(meters, toUnit);

                    userOutput.setText(String.format("%.6f", convertedValue));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number.");
                }
            }

            private double convertToMeters(double value, String fromUnit) {
                switch (fromUnit) {
                    case "meters": return value;
                    case "centimeters": return value / 100.0;
                    case "kilometers": return value * 1000.0;
                    case "millimeters": return value / 1000.0;
                    case "inches": return value * 0.0254;
                    case "yards": return value * 0.9144;
                    case "feet": return value * 0.3048;
                    default: return value;
                }
            }

            private double convertFromMeters(double meters, String toUnit) {
                switch (toUnit) {
                    case "meters": return meters;
                    case "centimeters": return meters * 100.0;
                    case "kilometers": return meters / 1000.0;
                    case "millimeters": return meters * 1000.0;
                    case "inches": return meters / 0.0254;
                    case "yards": return meters / 0.9144;
                    case "feet": return meters / 0.3048;
                    default: return meters;
                }
            }
        });


        convertButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                convertButton.setBackground(new Color(46, 139, 87));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                convertButton.setBackground(new Color(60, 179, 113));
            }
        });

        JLabel mainuserlabel2 = new JLabel("TEMPERATURE CONVERSION");
        mainuserlabel2.setFont(new Font("SansSerif", Font.BOLD, 18));
        mainuserlabel2.setForeground(new Color(0, 102, 204));
        mainuserlabel2.setBounds(10, 200, 1000, 25);
        add(mainuserlabel2);

        JLabel userLabel3 = new JLabel("ENTER VALUE:");
        userLabel3.setBounds(10, 240, 100, 25);
        add(userLabel3);

        JTextField userInput2 = new JTextField();
        userInput2.setBounds(120, 240, 100, 25);
        userInput2.setToolTipText("Enter a numeric value");
        add(userInput2);

        String[] tempunits = {"Celsius", "Farenheit", "Kelvin", "Rankine", "Reaumur"};
        JComboBox<String> comboBox3 = new JComboBox<>(tempunits);
        comboBox3.setBounds(230, 240, 120, 25);
        comboBox3.setToolTipText("Select unit to convert from");
        add(comboBox3);

        JLabel userLabel4 = new JLabel("CONVERTED VALUE:");
        userLabel4.setBounds(10, 280, 150, 25);
        add(userLabel4);

        JTextField userOutput2 = new JTextField();
        userOutput2.setBounds(140, 280, 100, 25);
        userOutput2.setEditable(false);
        userOutput2.setToolTipText("Converted result will appear here");
        add(userOutput2);

        JComboBox<String> comboBox4 = new JComboBox<>(tempunits);
        comboBox4.setBounds(250, 280, 100, 25);
        comboBox4.setToolTipText("Select unit to convert to");
        add(comboBox4);

        JButton convertButton2 = new JButton("Convert");
        convertButton2.setBounds(10, 320, 100, 30);
        convertButton2.setBackground(new Color(255, 140, 0));
        convertButton2.setForeground(Color.WHITE);
        convertButton2.setFocusPainted(false);
        convertButton2.setToolTipText("Click to convert");
        add(convertButton2);

        convertButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double inputValue2 = Double.parseDouble(userInput2.getText());
                    String fromUnit2 = (String) comboBox3.getSelectedItem();
                    String toUnit2 = (String) comboBox4.getSelectedItem();

                    double celsius = convertToCelsius(inputValue2, fromUnit2);
                    double convertedValue = convertFromCelsius(celsius, toUnit2);

                    userOutput2.setText(String.format("%.6f", convertedValue));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number.");
                }
            }

            private double convertToCelsius(double value, String fromUnit) {
                switch (fromUnit) {
                    case "Celsius": return value;
                    case "Farenheit": return (value - 32) * 5 / 9;
                    case "Kelvin": return value - 273.15;
                    case "Rankine": return (value - 491.67) * 5 / 9;
                    case "Reaumur": return value * 1.25;
                    default: return value;
                }
            }

            private double convertFromCelsius(double celsius, String toUnit) {
                switch (toUnit) {
                    case "Celsius": return celsius;
                    case "Farenheit": return (celsius * 9 / 5) + 32;
                    case "Kelvin": return celsius + 273.15;
                    case "Rankine": return (celsius + 273.15) * 9 / 5;
                    case "Reaumur": return celsius * 0.8;
                    default: return celsius;
                }
            }
        });

        convertButton2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                convertButton2.setBackground(new Color(255, 165, 0));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                convertButton2.setBackground(new Color(255, 140, 0));
            }
        });
    }
}
