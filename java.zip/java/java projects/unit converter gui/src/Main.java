import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        JFrame frame= new JFrame();
        frame.setTitle("GUI CONVERTER");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setSize(400,400);

        ConverterPanel panel = new ConverterPanel();
        frame.add(panel);

        frame.setVisible(true);


    }
}